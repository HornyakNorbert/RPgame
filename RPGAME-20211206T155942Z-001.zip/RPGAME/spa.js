let container = document.getElementById("container")

function clearContainer(){
    container.innerHTML= "";
}


function characterPage(){
    clearContainer();
/*

Add btn megjelenítését megoldani

*/


    container.innerHTML += `
    <h1>${stats.hero_name}</h1>
    <img class="kep" src="boby.jpg" alt="">
    <div class="outerHP">
        <div class="innerHP" id="HP"></div>
        <span id="num">${stats.hp}/${stats.max_hp}</span>
    </div>
    <table>
            <tr>
                <td>Erő:</td> 
                <td>${stats.strength}</td>
                <td><button class="addPoint" onclick="addPoint('strength')">+</button></td>
            </tr>
            <tr>
                <td>Ügyesség:</td> 
                <td>${stats.agility}</td>
                <td><button class="addPoint" onclick="addPoint('agility')">+</button></td>
            </tr>
            <tr>
                <td>Sebzés: ${stats.damage.min + stats.strength} - ${stats.damage.max + stats.strength}</td>
            </tr>
            <tr>
                <td>Védelem:</td> 
                <td>${stats.defense}</td>
                <td><button class="addPoint" onclick="addPoint('defense')">+</button></td>
            </tr>
    </table>
    `

    let addbuttons = document.getElementsByClassName('addPoint')
    if(stats.skill_points > 0){
        for(let i=0; i < addbuttons.length; i++){
            addbuttons[i].style.display = "block";
        }
    }
    let hp = document.getElementById("HP")
    hp.style.width = (stats.hp / stats.max_hp) *100 +"%"
}
characterPage();


function addPoint(ctx){
    stats[ctx]++
    stats.skill_points--

    characterPage();
}

function advanturePage(){
    clearContainer();
    container.innerHTML +=`
    <button onclick="easyAdventure()">Világos rét (könnyű)</button>
    <button onclick="mediumAdventure()">Sötét erdő (nehéz)</button>
    <button>Pokoli torony (pokolian nehéz)</button>
    `
}


function easyAdventure(){

    container.innerHTML = `<h2>Will Wilson megtámad</h2>
    <img class="harc" src="boby.jpg" title="Boby a rendíthetetlen" > VS  
    <img class="harc" src="will.jpg">
    <button class="indito" onclick="fight(wilson)">attack</button>
    `
    
}

function fight(enemy){
    let playerRound = false;
   let damage = 5;
    while(enemy.hp > 0 && stats.hp > 0){
if (playerRound){
    damage = Math.floor(Math.random()*stats.damage.max) + stats.damage.min 
    enemy.hp -= damage
    container.innerHTML += `<p>Rárontasz a ${enemy.name}-ra! ${damage} sebeztél</p>`
}
else{
    damage = Math.floor(Math.random()*enemy.damage.max) + enemy.damage.min
    stats.hp -= damage
    container.innerHTML += `<p>${enemy.name}-től ${damage} sebzést szendvedtél el.</p>`
    
}
playerRound =!playerRound
    }
    if(stats.hp <= 0){
        container.innerHTML += `<strong>MEGHALTÁL!!!44!!4!4!!!!4!!!!</strong>`
    }
    else{
        container.innerHTML += `<strong>NYERTÉL</strong>`
        
        
    }
 
}

function mediumAdventure(){
    container.innerHTML = `<h2>Tai Chi megtámad</h2>
    <button onclick="fight(chi)">attack</button>
    `
}


