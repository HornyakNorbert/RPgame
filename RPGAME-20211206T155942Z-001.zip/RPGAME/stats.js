let stats = {
    "level" : 1,
    "skill_points" : 5,
    "hero_name" : "Boby",
    "max_hp" : 220,
    "hp" : 220,
    "strength" : 7,
    "agility" : 5,
    "damage" : {
        "min":8,
        "max":14,
    },
    "defense" : 10,
}

let wilson = {
    "level" : 1,
    "name" : "Wilson",
    "max_hp" : 170,
    "hp" : 170,
    "strength" : 6,
    "agility" : 3,
    "damage" : {
        "min":6,
        "max":12,
    },
    "defense" : 6,
}

let chi = {
    "level" : 2,
    "name" : "Tai Chi",
    "max_hp" : 285,
    "hp" : 285,
    "strength" : 6,
    "agility" : 1,
    "damage" : {
        "min":4,
        "max":14,
    },
    "defense" : 4,
}